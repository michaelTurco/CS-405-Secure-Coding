// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// Test that adding an entry to a collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());

    // if not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);
}

// Test that adding five entries to a collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());

    // if not empty, the size must be 5
    ASSERT_EQ(collection->size(), 5);
}

// Test that max size is greater or equal to the size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterOrEqualToSize)
{
    // 0 entries (default amount)
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(1); // total entries: 1
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(4); // total entries: 5
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(5); // total entries: 10
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test that capacity is greater or equal to the size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterOrEqualToSize)
{
    // 0 entries (default amount)
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(1); // total entries: 1
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(4); // total entries: 5
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(5); // total entries: 10
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test that resizing increases the collection size
TEST_F(CollectionTest, ResizeIncreasesSize)
{
    ASSERT_EQ(collection->size(), 0);

    collection->resize(1);
    ASSERT_EQ(collection->size(), 1);

    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
    
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}

// Test that resizing decreases the collection size
TEST_F(CollectionTest, ResizeDecreasesSize)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10);

    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);

    collection->resize(1);
    ASSERT_EQ(collection->size(), 1);

    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
}

// Test that resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero)
{
    add_entries(10);

    collection->resize(0);
    
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test that clear erases the collection
TEST_F(CollectionTest, ClearErasesAllEntries)
{
    add_entries(10);

    collection->clear();

    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test that erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseEntries)
{
    add_entries(10);

    // erase all the entries
    collection->erase(collection->begin(), collection->end());

    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test reserve increasing capacity without changing size
TEST_F(CollectionTest, ReserveIncresesCapacityNotSize)
{
    collection->reserve(10);

    // capacity increases to 10, size stays the same
    ASSERT_EQ(collection->capacity(), 10);
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);
    
    // capacity remains the same, size increases
    ASSERT_EQ(collection->capacity(), 10);
    ASSERT_EQ(collection->size(), 5);
}

// Negative test for std::out_of_range exception
TEST_F(CollectionTest, AtThrowsOutOfRangeException)
{
    ASSERT_THROW(collection->at(2), std::out_of_range);

    add_entries(5);

    ASSERT_NO_THROW(collection->at(2), std::out_of_range);

    ASSERT_THROW(collection->at(10), std::out_of_range);

}

// 2 custom unit tests:

// Test pop_back decreases size
TEST_F(CollectionTest, PopBackDecreasesSize)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    collection->pop_back();
    ASSERT_EQ(collection->size(), 4);

    collection->pop_back();
    ASSERT_EQ(collection->size(), 3);
}

// Negative test resize throwing std::length_error exception with size too large
TEST_F(CollectionTest, ResizeThrowsLengthErrorException) {
    ASSERT_THROW(collection->resize(collection->max_size() + 1), std::length_error);
}